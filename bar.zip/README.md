# BarFlow - Sistema de Gestão para Bares e Restaurantes

## Sistema Completo de Gestão

O BarFlow é um sistema completo de gestão para bares e restaurantes, desenvolvido com as melhores práticas do mercado, similar aos sistemas utilizados por redes como Dunkin' Donuts.

## Módulos Incluídos

| Módulo | Descrição |
|--------|-----------|
| **PDV Touch** | Frente de caixa com interface touch otimizada |
| **KDS** | Kitchen Display System para cozinha |
| **Mesas** | Gestão visual de mesas |
| **Delivery Hub** | Integração com iFood, Rappi, Uber Eats |
| **CRM** | Gestão de clientes e fidelidade |
| **Estoque** | Controle de estoque e fichas técnicas |
| **Fiscal** | Emissão de NFC-e e NF-e |
| **Dashboard** | Relatórios e métricas |
| **App Cliente** | Aplicativo white-label para clientes |

## Como Acessar

### Opção 1: Deploy Online

#### Vercel (Recomendado)
```bash
# 1. Instale o Vercel CLI
npm i -g vercel

# 2. Entre na pasta do projeto
cd C:\Dev\Bar-Restaurante

# 3. Faça deploy
vercel
```

#### Netlify
1. Acesse [netlify.com](https://netlify.com)
2. Arraste a pasta do projeto para a área de deploy
3. Pronto!

### Opção 2: Servidor Local

#### Python (já vem com Windows)
```bash
# Abra o terminal na pasta do projeto
cd C:\Dev\Bar-Restaurante
python -m http.server 8000
```
Acesse: `http://localhost:8000`

#### Node.js
```bash
# Se tiver Node.js instalado
npx http-server -p 8000
```

## Estrutura dos Arquivos

```
Bar-Restaurante/
├── menu.html          # Menu principal
├── index.html         # PDV Touch Screen
├── kds.html          # Kitchen Display System
├── mesas.html        # Gestão de Mesas
├── dashboard.html    # Financeiro/Relatórios
├── crm-fidelidade.html  # CRM e Fidelidade
├── app-cliente.html  # App White-Label
├── estoque.html      # Gestão de Estoque
├── delivery-hub.html # Delivery Hub
├── fiscal.html       # Módulo Fiscal
├── manifest.json     # PWA Config
└── vercel.json      # Deploy Config
```

## Tecnologias

- HTML5, CSS3, JavaScript (puro)
- Chart.js para gráficos
- PWA (Progressive Web App)
- Design responsivo

## Para Testar no Celular (Mesma Rede)

1. Inicie o servidor local
2. Descubra seu IP: `ipconfig` (Windows) ou `ifconfig` (Mac/Linux)
3. Acesse: `http://SEU_IP:8000`

## Licença

MIT License - Livre para uso comercial

---

**Desenvolvido com ❤️ para o mercado brasileiro de food service**
