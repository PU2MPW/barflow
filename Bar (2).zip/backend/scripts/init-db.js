import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const db = new Database(join(__dirname, '..', 'data', 'barflow.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const schema = `
-- Empresa/Configurações
CREATE TABLE IF NOT EXISTS empresa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cnpj TEXT,
    telefone TEXT,
    email TEXT,
    endereco TEXT,
    logo TEXT,
    config_fiscal INTEGER DEFAULT 0,
    certificado_data TEXT,
    csc TEXT,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Usuários/Funcionários
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf TEXT UNIQUE,
    pin TEXT,
    tipo TEXT DEFAULT 'atendente',
    ativo INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Categorias
CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    icone TEXT,
    ordem INTEGER DEFAULT 0,
    ativo INTEGER DEFAULT 1
);

-- Produtos
CREATE TABLE IF NOT EXISTS produtos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    categoria_id INTEGER REFERENCES categorias(id),
    nome TEXT NOT NULL,
    descricao TEXT,
    preco REAL NOT NULL,
    preco_promocional REAL,
    imagem TEXT,
    icone TEXT DEFAULT '🍽️',
    controla_estoque INTEGER DEFAULT 0,
    estoque_minimo REAL DEFAULT 0,
    estoque_atual REAL DEFAULT 0,
    tempo_preparo INTEGER DEFAULT 15,
    ativo INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Mesas
CREATE TABLE IF NOT EXISTS mesas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero TEXT UNIQUE NOT NULL,
    capacidade INTEGER DEFAULT 4,
    posicao_x INTEGER,
    posicao_y INTEGER,
    status TEXT DEFAULT 'disponivel',
    ativo INTEGER DEFAULT 1
);

-- Pedidos
CREATE TABLE IF NOT EXISTS pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mesa_id INTEGER REFERENCES mesas(id),
    garcom_id INTEGER REFERENCES usuarios(id),
    cliente_id INTEGER REFERENCES clientes(id),
    tipo TEXT DEFAULT 'mesa',
    status TEXT DEFAULT 'aberto',
    subtotal REAL DEFAULT 0,
    desconto REAL DEFAULT 0,
    taxa_entrega REAL DEFAULT 0,
    total REAL DEFAULT 0,
    metodo_pagamento TEXT,
    observacoes TEXT,
    codigo TEXT UNIQUE,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Itens do Pedido
CREATE TABLE IF NOT EXISTS pedido_itens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pedido_id INTEGER REFERENCES pedidos(id),
    produto_id INTEGER REFERENCES produtos(id),
    quantidade REAL DEFAULT 1,
    preco_unitario REAL,
    observacao TEXT,
    status TEXT DEFAULT 'pendente',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Clientes/CRM
CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT UNIQUE,
    email TEXT,
    cpf TEXT,
    data_nascimento TEXT,
    endereco TEXT,
    pontos INTEGER DEFAULT 0,
    total_gasto REAL DEFAULT 0,
    visitas INTEGER DEFAULT 0,
    ativo INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Programa Fidelidade
CREATE TABLE IF NOT EXISTS fidelidade_recompensas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    descricao TEXT,
    pontos_necessarios INTEGER NOT NULL,
    tipo TEXT DEFAULT 'desconto',
    valor TEXT,
    ativo INTEGER DEFAULT 1
);

-- Resgates
CREATE TABLE IF NOT EXISTS fidelidade_resgates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER REFERENCES clientes(id),
    recompensa_id INTEGER REFERENCES fidelidade_recompensas(id),
    pontos_usados INTEGER,
    data TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Cupons
CREATE TABLE IF NOT EXISTS cupons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT UNIQUE NOT NULL,
    tipo TEXT DEFAULT 'percentual',
    valor REAL DEFAULT 0,
    valor_minimo REAL DEFAULT 0,
    limite_uso INTEGER DEFAULT 1,
    uso_atual INTEGER DEFAULT 0,
    validade TEXT,
    ativo INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Cupom usages
CREATE TABLE IF NOT EXISTS cupom_usos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cupom_id INTEGER REFERENCES cupons(id),
    pedido_id INTEGER REFERENCES pedidos(id),
    cliente_id INTEGER REFERENCES clientes(id),
    data TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Fluxo de Caixa
CREATE TABLE IF NOT EXISTS fluxo_caixa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT NOT NULL,
    categoria TEXT,
    descricao TEXT,
    valor REAL NOT NULL,
    forma_pagamento TEXT,
    operador_id INTEGER REFERENCES usuarios(id),
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Abertura/Fechamento de Caixa
CREATE TABLE IF NOT EXISTS caixa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    operador_id INTEGER REFERENCES usuarios(id),
    tipo TEXT NOT NULL,
    valor_inicial REAL,
    valor_final REAL,
    saldo REAL,
    observacoes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Sangrias
CREATE TABLE IF NOT EXISTS sangrias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    caixa_id INTEGER REFERENCES caixa(id),
    operador_id INTEGER REFERENCES usuarios(id),
    valor REAL NOT NULL,
    motivo TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Entregadores
CREATE TABLE IF NOT EXISTS entregadores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT,
    cpf TEXT,
    placa TEXT,
    tipo_veiculo TEXT,
    comissao_percentual REAL DEFAULT 20,
    total_entregas INTEGER DEFAULT 0,
    saldo REAL DEFAULT 0,
    ativo INTEGER DEFAULT 1,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Entregas
CREATE TABLE IF NOT EXISTS entregas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pedido_id INTEGER REFERENCES pedidos(id),
    entregador_id INTEGER REFERENCES entregadores(id),
    status TEXT DEFAULT 'preparando',
    taxa_entrega REAL,
    comissao REAL,
    tempo_estimado INTEGER,
    tempo_real INTEGER,
    endereco_entrega TEXT,
    observacoes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Reservas
CREATE TABLE IF NOT EXISTS reservas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER REFERENCES clientes(id),
    nome TEXT NOT NULL,
    telefone TEXT NOT NULL,
    mesa_id INTEGER REFERENCES mesas(id),
    data TEXT NOT NULL,
    hora TEXT NOT NULL,
    pessoas INTEGER DEFAULT 1,
    observacoes TEXT,
    status TEXT DEFAULT 'confirmada',
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

-- KDS - Kitchen Display System
CREATE TABLE IF NOT EXISTS kds_itens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pedido_id INTEGER REFERENCES pedidos(id),
    item_id INTEGER REFERENCES pedido_itens(id),
    status TEXT DEFAULT 'pendente',
    tempo_inicio INTEGER,
    tempo_fim INTEGER,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Zonas de Entrega
CREATE TABLE IF NOT EXISTS zonas_entrega (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    taxa REAL DEFAULT 0,
    tempo_entrega INTEGER DEFAULT 30,
    ativo INTEGER DEFAULT 1
);

-- Logs de Auditoria
CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER,
    acao TEXT NOT NULL,
    tabela TEXT,
    registro_id INTEGER,
    dados_antigos TEXT,
    dados_novos TEXT,
    ip TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Sessões
CREATE TABLE IF NOT EXISTS sessoes (
    id TEXT PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios(id),
    token TEXT,
    ip TEXT,
    user_agent TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    expires_at TEXT
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_pedidos_status ON pedidos(status);
CREATE INDEX IF NOT EXISTS idx_pedidos_mesa ON pedidos(mesa_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_created ON pedidos(created_at);
CREATE INDEX IF NOT EXISTS idx_pedido_itens_pedido ON pedido_itens(pedido_id);
CREATE INDEX IF NOT EXISTS idx_clientes_telefone ON clientes(telefone);
CREATE INDEX IF NOT EXISTS idx_produtos_categoria ON produtos(categoria_id);
CREATE INDEX IF NOT EXISTS idx_mesas_status ON mesas(status);
CREATE INDEX IF NOT EXISTS idx_kds_status ON kds_itens(status);
CREATE INDEX IF NOT EXISTS idx_entregas_status ON entregas(status);
`;

db.exec(schema);
console.log('✅ Schema criado com sucesso!');

db.close();